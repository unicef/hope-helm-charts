# Changelog

## 0.9.5 (2026-10-05)
* Add KEDA ScaledObject for the celery worker (`celery.keda`), disabled by default
* Add `celery.terminationGracePeriodSeconds`

## 0.9.4 (2026-07-14)
* Add backend `HorizontalPodAutoscaler` template (`autoscaling/v2`), gated on `backend.autoscaling.enabled`, with optional CPU and memory utilization targets
* Add `backend.autoscaling` values (minReplicas 1, maxReplicas 3, targetCPUUtilizationPercentage 80)
* Add top-level `resources: {}` shared by backend and celery worker; add celery `resources` / `beatResources` (worker falls back to top-level `resources`, beat to `celery.beatResources | default celery.resources`)

## 0.9.3 (2026-03-17)
* Redis: fix replica missing command/args/volumeMount defaults (same as master)

## 0.9.2 (2026-03-12)
* Redis: use official `redis:8` with custom ConfigMap

## 0.9.1 (2025-03-13)
* Flower: use ConfigMap for CELERY_BROKER_URL when set in backend.config (shared Redis), fallback to KeyVault for prod

## 0.9.0 (2026-02-11)
* Upgrade Redis to 24.1.8 and PostgreSQL to 13.x.x (OCI)
* Add redis.auth.enabled: false for Redis 24.x compatibility

## 0.6.0 (2025-05-21)
* Replaced Valkey with Redis
