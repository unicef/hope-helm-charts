# Changelog

## 0.14.1 (2026-03-12)
* Redis: default image to official `redis:8` (align with shared Redis pipeline)

## 0.14.0 (2026-02-11)
* Upgrade Redis to 24.1.8 and PostgreSQL to 13.x.x (OCI)

## 0.12.0 (2025-06-12)
* Changed path of image pull policy values from `image.pullPolicy` to `global.imagePullPolicy`

## 0.11.0 (2025-05-21)
* Replaced Valkey with Redis
