# Changelog

## 0.1.3 (2026-03-12)
* Redis: use official `redis:8` with custom ConfigMap (no loadmodule), same as pipelines/redis/cd/stg

## 0.1.2 (2026-02-10)
* Redis: pin to standalone (master only)

## 0.1.1 (2026-02-10)
* Upgrade redis dependency to 24.1.8 (Bitnami)

## 0.1.0 (2025-07-17)
* Initial release
