# Changelog

## 0.1.2 (2026-03-12)
* Redis: use official `redis:8` with custom ConfigMap (no loadmodule), same as pipelines/redis/cd/stg

## 0.1.1 (2026-02-11)
* Upgrade Redis to 24.1.8 (OCI)
* Add redis.auth.enabled: false for Redis 24.x compatibility

## 0.1.0 (2025-06-15)
* Initial chart release